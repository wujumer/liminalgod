import json, math, os
from PIL import Image, ImageDraw

R = "src/main/resources"
A = f"{R}/assets/liminalgod"
D = f"{R}/data/liminalgod"

# ---------------------------------------------------------------- canavar dokuları
BLACK = (8, 6, 8)
V = [
 # skin, hair, coat, pants, acc, eye(glow), eyestyle, mouth, extra
 dict(skin=(135,62,62), hair=(10,10,12), coat=(12,12,14), pants=(10,10,12), acc=(35,35,40), eye=(255,30,30), es='hollow', mouth='long', extra=''),          # 1 Uzun Adam
 dict(skin=(170,200,210), hair=(40,70,90), coat=(30,70,90), pants=(25,60,80), acc=(60,110,130), eye=(90,255,255), es='hollow', mouth='o', extra=''),     # 2 Yansıma
 dict(skin=(110,130,90), hair=(60,40,20), coat=(70,50,30), pants=(50,60,40), acc=(200,160,40), eye=(255,200,0), es='dots', mouth='stitched', extra='cap'),# 3 Bahçıvan
 dict(skin=(240,240,240), hair=(230,40,40), coat=(240,200,40), pants=(40,160,60), acc=(40,80,230), eye=(255,0,0), es='hollow', mouth='smile', extra='nose', stripe=True), # 4 Palyaço
 dict(skin=(200,190,170), hair=(60,60,60), coat=(50,60,90), pants=(30,30,40), acc=(160,30,30), eye=(255,255,255), es='dots', mouth='none', extra=''),     # 5 Müdür
 dict(skin=(20,20,22), hair=(5,5,5), coat=(50,50,55), pants=(25,25,30), acc=(255,200,0), eye=(255,220,60), es='hollow', mouth='long', extra=''),         # 6 Sarı Gözlü
 dict(skin=(225,215,200), hair=(225,215,200), coat=(230,230,230), pants=(210,210,210), acc=(180,180,180), eye=None, es='none', mouth='none', extra=''),   # 7 Manken
 dict(skin=(210,200,190), hair=(255,255,255), coat=(180,220,200), pants=(170,210,190), acc=(180,30,30), eye=(100,255,100), es='hollow', mouth='mask', extra=''), # 8 Hemşire
 dict(skin=(160,130,110), hair=(140,20,20), coat=(120,20,30), pants=(30,30,30), acc=(220,180,50), eye=(255,255,255), es='dots', mouth='stitched', extra='cap'), # 9 Kapıcı
 dict(skin=(190,170,150), hair=(80,80,80), coat=(90,90,95), pants=(50,50,55), acc=(30,30,30), eye=None, es='none', mouth='none', extra=''),              # 10 Memur (yüzsüz)
 dict(skin=(240,200,180), hair=(230,200,100), coat=(240,130,170), pants=(240,130,170), acc=(255,255,255), eye=(255,255,255), es='hollow', mouth='stitched', extra='cheeks'), # 11 Bebek
 dict(skin=(150,150,160), hair=(30,30,30), coat=(60,70,100), pants=(40,40,50), acc=(230,230,50), eye=(255,60,60), es='dots', mouth='long', extra=''),    # 12 Yolcu
 dict(skin=(110,150,140), hair=(30,60,40), coat=(30,50,50), pants=(20,40,45), acc=(60,110,90), eye=(120,255,200), es='hollow', mouth='o', extra=''),    # 13 Boğulmuş
 dict(skin=(200,200,190), hair=(20,10,10), coat=(25,10,10), pants=(20,8,8), acc=(180,20,20), eye=(255,0,0), es='dots', mouth='none', extra='hood'),      # 14 Rahip
 dict(skin=(170,60,70), hair=(110,20,30), coat=(140,30,45), pants=(100,20,35), acc=(230,200,180), eye=(255,255,0), es='hollow', mouth='long', extra='multi'), # 15 Parçalar
]

def make(v, i):
    im = Image.new("RGBA", (64, 64), (0, 0, 0, 0)); d = ImageDraw.Draw(im)
    ey = Image.new("RGBA", (64, 64), (0, 0, 0, 0)); e = ImageDraw.Draw(ey)
    skin, hair, coat, pants, acc = v['skin'], v['hair'], v['coat'], v['pants'], v['acc']
    # kafa
    d.rectangle([0, 8, 31, 15], fill=skin); d.rectangle([8, 0, 23, 7], fill=skin)
    d.rectangle([8, 0, 23, 7], fill=hair)               # üst/alt
    d.rectangle([0, 8, 31, 9], fill=hair)               # saç çizgisi
    d.rectangle([24, 8, 31, 15], fill=hair)             # arka
    if v['extra'] == 'hood':
        d.rectangle([8, 8, 9, 15], fill=hair); d.rectangle([14, 8, 15, 15], fill=hair); d.rectangle([8, 8, 15, 10], fill=hair)
    if v['extra'] == 'cap':
        d.rectangle([8, 8, 15, 10], fill=hair)
    # gövde ve kollar
    d.rectangle([16, 16, 39, 31], fill=coat)
    d.rectangle([40, 16, 55, 31], fill=coat); d.rectangle([32, 48, 47, 63], fill=coat)
    d.rectangle([40, 28, 55, 31], fill=skin); d.rectangle([32, 60, 47, 63], fill=skin)   # eller
    # bacaklar
    d.rectangle([0, 16, 15, 31], fill=pants); d.rectangle([16, 48, 31, 63], fill=pants)
    d.rectangle([0, 29, 15, 31], fill=BLACK); d.rectangle([16, 61, 31, 63], fill=BLACK)  # ayakkabı
    # aksesuar şeridi (kravat / önlük)
    d.rectangle([23, 20, 24, 27], fill=acc)
    if v.get('stripe'):
        for y in range(20, 32, 4):
            d.rectangle([16, y, 39, y + 1], fill=acc); d.rectangle([40, y, 55, y + 1], fill=acc)
    # yüz (ön yüz: x 8..15, y 8..15)
    s = v['es']
    if s == 'hollow':
        d.rectangle([9, 11, 10, 12], fill=BLACK); d.rectangle([13, 11, 14, 12], fill=BLACK)
        if v['eye']:
            e.rectangle([9, 12, 10, 12], fill=v['eye']); e.rectangle([13, 12, 14, 12], fill=v['eye'])
    elif s == 'dots':
        d.point((10, 11), fill=BLACK); d.point((13, 11), fill=BLACK)
        if v['eye']:
            e.point((10, 11), fill=v['eye']); e.point((13, 11), fill=v['eye'])
    m = v['mouth']
    if m == 'long':
        d.rectangle([10, 13, 13, 15], fill=(10, 0, 0)); d.point((11, 14), fill=(120, 20, 20)); d.point((12, 15), fill=(120, 20, 20))
        d.rectangle([22, 20, 25, 31], fill=(10, 0, 0)) if False else None
    elif m == 'o':
        d.rectangle([11, 13, 12, 14], fill=(5, 5, 8))
    elif m == 'smile':
        d.point((9, 13), fill=(200, 20, 20)); d.point((14, 13), fill=(200, 20, 20))
        d.rectangle([10, 14, 13, 14], fill=(200, 20, 20)); d.rectangle([10, 15, 13, 15], fill=(255, 255, 255))
    elif m == 'stitched':
        d.rectangle([9, 14, 14, 14], fill=(20, 10, 10))
        for x in (10, 12, 14): d.line([(x, 13), (x, 15)], fill=(20, 10, 10))
    elif m == 'mask':
        d.rectangle([9, 13, 14, 15], fill=(150, 200, 220))
    if v['extra'] == 'nose':
        d.rectangle([11, 12, 12, 13], fill=(230, 20, 20))
    if v['extra'] == 'cheeks':
        d.point((9, 13), fill=(230, 80, 90)); d.point((14, 13), fill=(230, 80, 90))
    if v['extra'] == 'multi':
        for x in (9, 12, 14):
            d.point((x, 10), fill=BLACK); e.point((x, 10), fill=v['eye'])
    im.save(f"{A}/textures/entity/anomaly_{i}.png"); ey.save(f"{A}/textures/entity/anomaly_{i}_eyes.png")

for i, v in enumerate(V): make(v, i)

# ---------------------------------------------------------------- portal ve anahtar dokusu
p = Image.new("RGBA", (16, 16))
for x in range(16):
    for y in range(16):
        dx, dy = x - 7.5, y - 7.5
        r = math.hypot(dx, dy); a = math.atan2(dy, dx)
        w = (math.sin(a * 3 + r * 1.2) + 1) / 2
        if r < 3: c = (4, 0, 8)
        elif r < 8: c = (int(30 + 110 * w), 0, int(50 + 140 * w))
        else: c = (10, 0, 16)
        p.putpixel((x, y), c + (255,))
p.save(f"{A}/textures/block/portal.png")

k = Image.new("RGBA", (16, 16), (0, 0, 0, 0)); kd = ImageDraw.Draw(k)
kd.ellipse([3, 3, 12, 12], fill=(15, 8, 20), outline=(140, 20, 30))
kd.ellipse([6, 6, 9, 9], fill=(230, 40, 40))
kd.rectangle([7, 12, 8, 15], fill=(140, 20, 30))
k.save(f"{A}/textures/item/portal_key.png")

# ---------------------------------------------------------------- modeller, blockstate, dil
def w(path, obj):
    os.makedirs(os.path.dirname(path), exist_ok=True)
    with open(path, "w", encoding="utf-8") as f: json.dump(obj, f, ensure_ascii=False, indent=2)

w(f"{A}/blockstates/portal.json", {"variants": {"": {"model": "liminalgod:block/portal"}}})
w(f"{A}/models/block/portal.json", {
    "textures": {"all": "liminalgod:block/portal", "particle": "liminalgod:block/portal"},
    "elements": [{"from": [0, 0, 0], "to": [16, 1, 16], "faces": {
        "up": {"texture": "#all"}, "down": {"texture": "#all"}}}]})
w(f"{A}/models/item/portal_key.json", {"parent": "minecraft:item/generated", "textures": {"layer0": "liminalgod:item/portal_key"}})
lang = {"item.liminalgod.portal_key": "Eşik Anahtarı", "block.liminalgod.portal": "Liminal Portal",
        "entity.liminalgod.anomaly": "Anomali"}
w(f"{A}/lang/en_us.json", lang); w(f"{A}/lang/tr_tr.json", lang)

w(f"{D}/recipes/portal_key.json", {"type": "minecraft:crafting_shapeless",
    "ingredients": [{"item": "minecraft:ender_pearl"}, {"item": "minecraft:book"}, {"item": "minecraft:ink_sac"}],
    "result": {"item": "liminalgod:portal_key"}})

# ---------------------------------------------------------------- boyutlar
def dtype(ambient, time):
    return {"ultrawarm": False, "natural": False, "coordinate_scale": 1.0, "has_skylight": False,
            "has_ceiling": True, "ambient_light": ambient, "fixed_time": time, "piglin_safe": False,
            "bed_works": False, "respawn_anchor_works": False, "has_raids": False, "logical_height": 256,
            "min_y": 0, "height": 256, "infiniburn": "#minecraft:infiniburn_overworld",
            "effects": "minecraft:overworld", "monster_spawn_light_level": 0, "monster_spawn_block_light_limit": 0}
w(f"{D}/dimension_type/dark.json", dtype(0.0, 18000))
w(f"{D}/dimension_type/bright.json", dtype(0.4, 6000))
w(f"{D}/dimension_type/white.json", dtype(1.0, 6000))

gen = {"type": "minecraft:flat", "settings": {"biome": "minecraft:the_void", "features": False, "lakes": False,
       "layers": [{"block": "minecraft:air", "height": 1}], "structure_overrides": []}}
BRIGHT = {2, 3, 4, 7, 10, 11}
for i in range(1, 16):
    w(f"{D}/dimension/level_{i:02d}.json", {"type": "liminalgod:" + ("bright" if i in BRIGHT else "dark"), "generator": gen})
w(f"{D}/dimension/finale.json", {"type": "liminalgod:white", "generator": gen})
print("assets ok")
