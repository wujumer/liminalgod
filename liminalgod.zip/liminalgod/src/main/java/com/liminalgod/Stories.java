package com.liminalgod;

import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.nbt.NbtCompound;
import net.minecraft.nbt.NbtList;
import net.minecraft.nbt.NbtString;
import net.minecraft.text.Text;

public final class Stories {
	// { yazar, sayfa1, sayfa2, sayfa3 }
	private static final String[][] BOOKS = {
		{"Kemal",
			"§lSararmış Odalar§r\n\nBugünün kaç olduğunu bilmiyorum. Kapıyı açtım ve bu sarı odalara düştüm. Halı nemli, duvarlar hastalıklı bir sarı. Tepemdeki lambalardan hiç kesilmeyen bir vızıltı geliyor.",
			"Günlerce yürüdüm, hep aynı koridoru gördüm. Sonra tepemden bir ses geldi. Kahkaha gibiydi ama bir insan ağzından çıkmıyordu. 'Eğlenceye hoş geldin' dedi. Kimseyi göremedim.",
			"O ses Tanrı'ydı. Biz onun oyuncağıyız. Sıkıldığı için bizi buralara tıktı. Burada upuzun bir adam var, ağzı göğsüne kadar açılıyor. Bu kitabı bulduysan sen de buradasın. Koş."},
		{"Zeynep",
			"§lHavuz Odaları§r\n\nSu ılık ve hiç dalgalanmıyor. Her yer beyaz fayans. Havuzun dibinde kendime benzeyen bir şey gördüm. İlk önce yansımam sandım.",
			"Yansıma bana el salladı. Ben sallamamıştım. Annemin sesini duydum, adımı söylüyordu, sudan geliyordu. Peşinden gittim. Sen bu hatayı yapma.",
			"Tanrı bizi tek tek topladı ve her birimizden bir parça alıp bu yerleri yaptı. Bu su benim gözyaşlarımdan, bu fayanslar dişlerimden. Yansıma ise içimde kalan kısmım. Çabuk ol, sandığı bul."},
		{"Ahmet",
			"§lÇimenli Salon§r\n\nBahçıvandım. Burada çimenler uzamıyor, çiçekler hiç solmuyor. Tavan hastane gibi beyaz, lambalar uğulduyor. Çok güzel görünüyor, değil mi?",
			"Güzel görünen şey en kötüsüdür. Çiçeklerin kökü toprakta değil, beton zeminin altında bir şeye bağlı. Kazdım. Kazmamalıydım.",
			"Altında insan elleri vardı. Çiçekler bizim parmaklarımızdan büyüyor. Tanrı bunu sanat sayıyor. Ben hâlâ bahçıvanım ama bu bahçe benim değil. Beni görürsen koş."},
		{"Deniz",
			"§lNeşe Sirki§r\n\nBurada müzik hiç durmuyor. Renkler çok parlak, balonlar tavandan sarkıyor. İlk başta sevindim, annemi çağırdım ama kimse gelmedi. Bir palyaço geldi.",
			"Gülüyordu ama gözleri gülmüyordu. 'Saklambaç oynayalım' dedi. Saydı, ben saklandım. Hâlâ sayıyor. Sesini her yerde duyuyorum, bitmeyen bir sayış.",
			"Tanrı çocukları sever çünkü çocuklar daha çok korkar, daha iyi eğlendirir. Bu kitabı okuyorsan palyaço saymayı bırakmadı demektir. Sakın durma. Sakın arkana bakma."},
		{"Ece",
			"§lOkul Koridoru§r\n\nZil çaldı ama ders hiç başlamadı. Sınıfların kapıları kilitli, tahtada hep aynı cümle yazıyor: 'Geç kalan cezalandırılır.' Koridor bitmiyor.",
			"Müdürün odasından ses geliyor. Kapıyı araladım, içeride kimse yoktu, sadece bir masa ve masanın üstünde yüzlerce kimlik kartı. Hepsinde bizim fotoğrafımız.",
			"Tanrı bizi kayıt altına aldı. Her birimiz bir öğrenci numarası olduk. Müdür sürekli dolaşıp geç kalanları arıyor. Beni de buldu. Zil çalarsa saklan."},
		{"Murat",
			"§lOtopark§r\n\nArabamı park edip asansöre bindim, kat düğmesine bastım ve buraya indim. Eksi yüz otuz yedinci kat. Hiç araç yok, sadece yağ lekeleri ve çok uzaktan gelen bir motor sesi.",
			"Işıklar zaman zaman sönüyor. Karanlıkta iki sarı nokta beliriyor. Gözleri far gibi yanan bir şey beni izliyor. Yaklaştıkça motor sesi artıyor.",
			"Tanrı bu yeri benim kaygılarımdan yaptı. Hep geç kalıyordum, şimdi hiç çıkamıyorum. Sarı gözlü şey araba değil, benden kalanlar. Işığı kapatma."},
		{"Selin",
			"§lAlışveriş Merkezi§r\n\nHoparlörden hep aynı müzik çalıyor, yavaşlatılmış bir melodi. Vitrinlerdeki mankenler ben yürüdükçe baş çeviriyor, bakınca duruyorlar.",
			"Sayıyorum: dün dokuz manken vardı, bugün on bir. Aralarından biri tanıdık duruyor. Üzerindeki kıyafet benim kıyafetim. Parmakları parmaklarıma çok benziyor.",
			"Tanrı insanları sergiler. Mankenler buraya düşenlerin son halidir. Alışveriş bitmiyor, kimse çıkışa varamıyor. Bir manken yerinden oynadıysa sakın arkana bakma."},
		{"Dr. Hakan",
			"§lHastane§r\n\nDoktorluk yaptım ama hasta hiç gelmedi. Koridorlar ilaç kokuyor, yatakların çarşafları boş ama sıcak. Hemşire bana hep aynı şeyi söylüyor: 'Sıra sizde.'",
			"Neyin sırası diye sordum. Maskesinin altından bir ses geldi: 'Parçalar.' Anlamadım. Sonra ameliyathaneyi gördüm. Masada kimse yoktu ama masa bizim kanımızla ıslaktı.",
			"Tanrı bu odaları bizim kemiklerimizden yaptı. Tedavi etmeye çalıştım ama bizi hasta eden şey buranın kendisiydi. Sıranı bekleme."},
		{"Burak",
			"§lOtel§r\n\nResepsiyonda kimse yok, sadece bir zil ve kırmızı bir halı. Odam 237. Anahtarı çevirdim ama hangi kata çıksam aynı koridora varıyorum. Kapıların ardından fısıltılar geliyor.",
			"Kapıcı her gece geliyor. Elinde kapaklı bir tepsi var. Hiç açmadım. Açmamı bekliyor. Biliyorum, içindeki şey benim kendi yüzüm.",
			"Tanrı beni misafir ediyor ama çıkış tarihini yazmadı. Bütün misafirleri kapıların arkasında tuttu. Tepsiyi açma. Hiç açma."},
		{"Aylin",
			"§lOfis§r\n\nSabahları işe geliyorum. Akşam hiç olmuyor, hep sabah. Telefonlar çalıyor ama arayanlar sadece nefes alıp veriyor. Bir yönetici her gün masama geliyor ve yüzü yok.",
			"Yüzsüz adam rapor istiyor. Hangi rapor, bilmiyorum. Çekmecemde bir dosya buldum: hepimizin performans değerlendirmesi. Hepsinin sonuna aynı not yazılmış: 'Eğlenceli.'",
			"Tanrı bizi izlerken eğleniyor, tıpkı bir ofis dizisi izler gibi. Biz çalışıyoruz, o kahkaha atıyor. Yüzsüz memur bana çok yaklaştı. Çıkışı bul."},
		{"Küçük Can",
			"§lOyun Odası§r\n\nBuradaki bebekler konuşuyor. 'Hadi oynayalım' diyorlar. İstemiyorum. Büyük bir bebek var, gözleri iki düğme, ağzı dikişli. Hem ağlıyor hem gülüyor.",
			"Bana bir kâğıt uzattı. Çocuk yazısıyla 'Annem nerede?' yazıyordu. Bu benim yazım. Ben yazmadım. Burada hiçbir şey benim değil, oyuncaklar bile.",
			"Tanrı oyuncakları çok sever. Bizi de oyuncağa çevirdi. Bebek beni saklıyor. Kitabı alıp gidebilirsen belki oyun biter. Belki."},
		{"Fatma",
			"§lMetro İstasyonu§r\n\nTren gelmiyor. Panoda saat yok, sadece 'bekleyiniz' yazıyor. Peronda yolcular var ama kıpırdamıyorlar. Hepsi tünele bakıyor.",
			"Birinin omzuna dokundum. Döndü, yüzünde sadece uzun bir ağız vardı. 'Tren geliyor' dedi. Kaç gündür bunu söylüyorlar. Tünelden bir ışık görünüyor ama yaklaşmıyor.",
			"Tanrı bu istasyonu bizim yarım kalmış yolculuklarımızdan yaptı. Yolcular gidemeyen ruhlar. Tren gelirse binme. O tren seni hiçbir yere götürmez."},
		{"Ali",
			"§lSular Altındaki Apartman§r\n\nMerdivenler suyun içine iniyor. Her kapının önünde ıslak ayakkabılar duruyor. Bir daireden televizyon sesi geliyor. Girdim, koltukta oturan biri boğulmuştu ama hâlâ izliyordu.",
			"Su yükseliyor. Her gün biraz daha. Çıkmaya çalıştım, tavan da suyla doluydu. Nefesimi tutmayı öğrendim. Ama onlar öğrenmiyor, onlar zaten nefes almıyor.",
			"Tanrı bu apartmanı bizim son nefeslerimizden yaptı. Komşularım suyun içinde yürüyor. Sana el sallarlarsa selam verme. Sandık bir yerlerde. Nefesini tut."},
		{"Mikail",
			"§lTerk Edilmiş Kilise§r\n\nİnançlıydım. Burada dua ettim ama tavan yukarı bakmama izin vermedi. Mumlar kendi kendine yanıyor. Hep aynı dua fısıldanıyor, tersinden.",
			"Rahip kürsüde duruyor, yüzü kapüşonun altında. 'Kimin için dua ediyorsun?' diye sordu. 'Tanrı için' dedim. Gülmeye başladı. Bütün kilise onunla gülmeye başladı.",
			"Burada tek bir tanrı var ve bizi buraya getiren o. Bütün dualar ona gidiyor çünkü başka muhatap yok. Bir gün o gelirse gözlerini kapat. Ona bakma."},
		{"Hepimiz",
			"§lEt Koridoru§r\n\nBunu sonuncu olarak yazıyorum. Duvarlar nefes alıyor, zemin sıcak. Burası diğer yerlerin temeli. Tanrı hepimizi buraya getirip parçalara ayırdı ve o yerleri bu parçalardan inşa etti.",
			"Duvarın içinde bir yüz gördüm. Bana benziyordu, belki de bendim. Diğerleri de buradaydı: Kemal, Zeynep, Ahmet, Deniz, Ece... Hepimiz tek bir bedenin parçaları olduk.",
			"On beş yer, on beş kitap. Hepsini bir araya getirirsen O kendi gelir, çünkü seyirci sahneyi merak eder. Bunu isteme. Ama başka çıkış da yok. Kitapları topla ve hazırlan: Tanrı geliyor."},
	};

	public static ItemStack book(int idx) {
		String[] b = BOOKS[idx];
		ItemStack stack = new ItemStack(Items.WRITTEN_BOOK);
		NbtCompound nbt = stack.getOrCreateNbt();
		nbt.putString("title", "Günlük " + (idx + 1));
		nbt.putString("author", b[0]);
		NbtList pages = new NbtList();
		for (int i = 1; i < b.length; i++) {
			pages.add(NbtString.of(Text.Serializer.toJson(Text.literal(b[i]))));
		}
		nbt.put("pages", pages);
		nbt.putInt("liminalgod_level", idx + 1);
		return stack;
	}

	private Stories() {}
}
