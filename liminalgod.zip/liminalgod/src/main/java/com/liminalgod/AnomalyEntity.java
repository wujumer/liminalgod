package com.liminalgod;

import net.minecraft.entity.EntityType;
import net.minecraft.entity.ai.goal.ActiveTargetGoal;
import net.minecraft.entity.ai.goal.LookAroundGoal;
import net.minecraft.entity.ai.goal.LookAtEntityGoal;
import net.minecraft.entity.ai.goal.MeleeAttackGoal;
import net.minecraft.entity.ai.goal.SwimGoal;
import net.minecraft.entity.ai.goal.WanderAroundFarGoal;
import net.minecraft.entity.attribute.DefaultAttributeContainer;
import net.minecraft.entity.attribute.EntityAttributes;
import net.minecraft.entity.data.DataTracker;
import net.minecraft.entity.data.TrackedData;
import net.minecraft.entity.data.TrackedDataHandlerRegistry;
import net.minecraft.entity.damage.DamageSource;
import net.minecraft.entity.mob.HostileEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.nbt.NbtCompound;
import net.minecraft.block.BlockState;
import net.minecraft.sound.SoundEvent;
import net.minecraft.sound.SoundEvents;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;

public class AnomalyEntity extends HostileEntity {
	private static final TrackedData<Integer> VARIANT =
			DataTracker.registerData(AnomalyEntity.class, TrackedDataHandlerRegistry.INTEGER);

	private static final SoundEvent[] AMBIENT = {
			SoundEvents.ENTITY_ENDERMAN_AMBIENT,        // 1 Uzun Adam
			SoundEvents.ENTITY_DROWNED_AMBIENT,         // 2 Yansıma
			SoundEvents.ENTITY_VEX_AMBIENT,             // 3 Bahçıvan
			SoundEvents.ENTITY_EVOKER_CELEBRATE,        // 4 Palyaço (kahkaha)
			SoundEvents.ENTITY_ZOMBIE_VILLAGER_AMBIENT, // 5 Müdür
			SoundEvents.ENTITY_PHANTOM_AMBIENT,         // 6 Sarı Gözlü
			SoundEvents.ENTITY_STRAY_AMBIENT,           // 7 Manken
			SoundEvents.ENTITY_WITCH_AMBIENT,           // 8 Hemşire
			SoundEvents.ENTITY_ILLUSIONER_AMBIENT,      // 9 Kapıcı
			SoundEvents.ENTITY_WARDEN_AMBIENT,          // 10 Memur
			SoundEvents.ENTITY_GHAST_AMBIENT,           // 11 Bebek (ağlama)
			SoundEvents.ENTITY_PILLAGER_AMBIENT,        // 12 Yolcu
			SoundEvents.ENTITY_DROWNED_AMBIENT,         // 13 Boğulmuş
			SoundEvents.ENTITY_VINDICATOR_AMBIENT,      // 14 Rahip
			SoundEvents.ENTITY_ZOGLIN_AMBIENT           // 15 Parçalar
	};

	public AnomalyEntity(EntityType<? extends AnomalyEntity> type, World world) {
		super(type, world);
		this.experiencePoints = 0;
	}

	public static DefaultAttributeContainer.Builder createAttributes() {
		return HostileEntity.createHostileAttributes()
				.add(EntityAttributes.GENERIC_MAX_HEALTH, 60.0)
				.add(EntityAttributes.GENERIC_MOVEMENT_SPEED, 0.27)
				.add(EntityAttributes.GENERIC_ATTACK_DAMAGE, 5.0)
				.add(EntityAttributes.GENERIC_FOLLOW_RANGE, 64.0)
				.add(EntityAttributes.GENERIC_KNOCKBACK_RESISTANCE, 0.6);
	}

	@Override
	protected void initDataTracker() {
		super.initDataTracker();
		this.dataTracker.startTracking(VARIANT, 0);
	}

	public int getVariant() {
		return this.dataTracker.get(VARIANT);
	}

	public void setVariant(int v) {
		this.dataTracker.set(VARIANT, v);
	}

	@Override
	protected void initGoals() {
		this.goalSelector.add(0, new SwimGoal(this));
		this.goalSelector.add(1, new ChaseGoal(this, 1.1));
		this.goalSelector.add(5, new WanderAroundFarGoal(this, 0.8));
		this.goalSelector.add(6, new LookAtEntityGoal(this, PlayerEntity.class, 24.0f));
		this.goalSelector.add(7, new LookAroundGoal(this));
		// false = duvarların arkasından bile oyuncuyu hisseder
		this.targetSelector.add(1, new ActiveTargetGoal<>(this, PlayerEntity.class, false));
	}

	@Override
	public void writeCustomDataToNbt(NbtCompound nbt) {
		super.writeCustomDataToNbt(nbt);
		nbt.putInt("Variant", getVariant());
	}

	@Override
	public void readCustomDataFromNbt(NbtCompound nbt) {
		super.readCustomDataFromNbt(nbt);
		setVariant(nbt.getInt("Variant"));
	}

	@Override
	public boolean canImmediatelyDespawn(double distanceSquared) {
		return false;
	}

	@Override
	public boolean isFireImmune() {
		return true;
	}

	@Override
	protected SoundEvent getAmbientSound() {
		return AMBIENT[Math.floorMod(getVariant(), AMBIENT.length)];
	}

	@Override
	protected SoundEvent getHurtSound(DamageSource source) {
		return SoundEvents.ENTITY_ZOMBIE_HURT;
	}

	@Override
	protected SoundEvent getDeathSound() {
		return SoundEvents.ENTITY_ZOMBIE_DEATH;
	}

	@Override
	protected void playStepSound(BlockPos pos, BlockState state) {
		this.playSound(SoundEvents.ENTITY_ZOMBIE_STEP, 0.15f, 0.8f);
	}

	@Override
	public int getMinAmbientSoundDelay() {
		return 120;
	}

	/** Kollar havada koşan, hiç pes etmeyen kovalama davranışı. */
	static class ChaseGoal extends MeleeAttackGoal {
		private final AnomalyEntity anomaly;

		ChaseGoal(AnomalyEntity entity, double speed) {
			super(entity, speed, true);
			this.anomaly = entity;
		}

		@Override
		public void start() {
			super.start();
			anomaly.setAttacking(true);
		}

		@Override
		public void stop() {
			super.stop();
			anomaly.setAttacking(false);
		}
	}
}
