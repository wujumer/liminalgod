package com.liminalgod;

import net.minecraft.block.AbstractBlock;
import net.minecraft.block.Block;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;

public class ModBlocks {
	public static final Block PORTAL = Registry.register(Registries.BLOCK, LiminalGod.id("portal"),
			new PortalBlock(AbstractBlock.Settings.create()
					.noCollision()
					.strength(-1.0f, 3600000.0f)
					.luminance(s -> 10)
					.nonOpaque()
					.dropsNothing()));

	public static void init() {
	}
}
