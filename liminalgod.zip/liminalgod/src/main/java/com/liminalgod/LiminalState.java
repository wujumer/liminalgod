package com.liminalgod;

import net.minecraft.nbt.NbtCompound;
import net.minecraft.nbt.NbtElement;
import net.minecraft.nbt.NbtList;
import net.minecraft.server.MinecraftServer;
import net.minecraft.world.PersistentState;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

public class LiminalState extends PersistentState {
	public static class Data {
		public int collected = 0;          // 15 bitlik maske
		public int current = -1;           // şu an bulunulan seviye
		public boolean hasRet = false;
		public String retWorld = "minecraft:overworld";
		public double x, y, z;
		public float yaw, pitch;
		public int returnTimer = -1;
		public int finaleTimer = -1;
		public boolean finale = false;
	}

	public final Map<UUID, Data> players = new HashMap<>();
	public int built = 0; // hangi seviyeler inşa edildi (bit 15 = final)

	public static LiminalState get(MinecraftServer server) {
		return server.getOverworld().getPersistentStateManager()
				.getOrCreate(LiminalState::fromNbt, LiminalState::new, "liminalgod");
	}

	public Data get(UUID id) {
		return players.computeIfAbsent(id, k -> new Data());
	}

	@Override
	public NbtCompound writeNbt(NbtCompound nbt) {
		nbt.putInt("built", built);
		NbtList list = new NbtList();
		for (Map.Entry<UUID, Data> e : players.entrySet()) {
			Data d = e.getValue();
			NbtCompound c = new NbtCompound();
			c.putUuid("id", e.getKey());
			c.putInt("collected", d.collected);
			c.putInt("current", d.current);
			c.putBoolean("hasRet", d.hasRet);
			c.putString("retWorld", d.retWorld);
			c.putDouble("x", d.x);
			c.putDouble("y", d.y);
			c.putDouble("z", d.z);
			c.putFloat("yaw", d.yaw);
			c.putFloat("pitch", d.pitch);
			c.putInt("returnTimer", d.returnTimer);
			c.putInt("finaleTimer", d.finaleTimer);
			c.putBoolean("finale", d.finale);
			list.add(c);
		}
		nbt.put("players", list);
		return nbt;
	}

	public static LiminalState fromNbt(NbtCompound nbt) {
		LiminalState s = new LiminalState();
		s.built = nbt.getInt("built");
		NbtList list = nbt.getList("players", NbtElement.COMPOUND_TYPE);
		for (int i = 0; i < list.size(); i++) {
			NbtCompound c = list.getCompound(i);
			Data d = new Data();
			d.collected = c.getInt("collected");
			d.current = c.getInt("current");
			d.hasRet = c.getBoolean("hasRet");
			d.retWorld = c.getString("retWorld");
			d.x = c.getDouble("x");
			d.y = c.getDouble("y");
			d.z = c.getDouble("z");
			d.yaw = c.getFloat("yaw");
			d.pitch = c.getFloat("pitch");
			d.returnTimer = c.getInt("returnTimer");
			d.finaleTimer = c.getInt("finaleTimer");
			d.finale = c.getBoolean("finale");
			s.players.put(c.getUuid("id"), d);
		}
		return s;
	}
}
