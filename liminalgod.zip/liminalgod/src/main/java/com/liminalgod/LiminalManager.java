package com.liminalgod;

import com.mojang.brigadier.arguments.IntegerArgumentType;
import net.fabricmc.fabric.api.command.v2.CommandRegistrationCallback;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.fabricmc.fabric.api.event.player.PlayerBlockBreakEvents;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.entity.player.PlayerInventory;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.registry.RegistryKey;
import net.minecraft.registry.RegistryKeys;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.command.CommandManager;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvents;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;

import java.util.*;

public final class LiminalManager {
	public static final int TOTAL = 15;
	public static final RegistryKey<World> FINALE =
			RegistryKey.of(RegistryKeys.WORLD, LiminalGod.id("finale"));

	private static final Map<UUID, Integer> PENDING = new HashMap<>();
	private static final Random RNG = new Random();

	public static RegistryKey<World> levelKey(int i) {
		return RegistryKey.of(RegistryKeys.WORLD, LiminalGod.id(String.format("level_%02d", i + 1)));
	}

	public static boolean isLiminal(World w) {
		return w.getRegistryKey().getValue().getNamespace().equals(LiminalGod.MOD_ID);
	}

	// ------------------------------------------------------------------ init
	public static void init() {
		ServerTickEvents.END_SERVER_TICK.register(LiminalManager::tick);

		// Liminal mekanlarda blok kırılmasın (sandık / duvarlar korunur)
		PlayerBlockBreakEvents.BEFORE.register((world, player, pos, state, be) ->
				player.isCreative() || !isLiminal(world));

		CommandRegistrationCallback.EVENT.register((dispatcher, registryAccess, environment) ->
				dispatcher.register(CommandManager.literal("liminal")
						.requires(s -> s.hasPermissionLevel(2))
						.then(CommandManager.literal("key").executes(c -> {
							ServerPlayerEntity p = c.getSource().getPlayerOrThrow();
							p.giveItemStack(new ItemStack(ModItems.PORTAL_KEY));
							return 1;
						}))
						.then(CommandManager.literal("go")
								.then(CommandManager.argument("n", IntegerArgumentType.integer(1, TOTAL))
										.executes(c -> {
											ServerPlayerEntity p = c.getSource().getPlayerOrThrow();
											int n = IntegerArgumentType.getInteger(c, "n");
											enterLevel(p, LiminalState.get(p.getServer()), n - 1);
											return 1;
										})))
						.then(CommandManager.literal("finale").executes(c -> {
							ServerPlayerEntity p = c.getSource().getPlayerOrThrow();
							LiminalState st = LiminalState.get(p.getServer());
							enterFinale(p, st, st.get(p.getUuid()));
							return 1;
						}))
						.then(CommandManager.literal("leave").executes(c -> {
							ServerPlayerEntity p = c.getSource().getPlayerOrThrow();
							LiminalState st = LiminalState.get(p.getServer());
							exit(p, st.get(p.getUuid()));
							st.markDirty();
							return 1;
						}))
						.then(CommandManager.literal("reset").executes(c -> {
							ServerPlayerEntity p = c.getSource().getPlayerOrThrow();
							LiminalState st = LiminalState.get(p.getServer());
							st.players.put(p.getUuid(), new LiminalState.Data());
							st.markDirty();
							p.sendMessage(Text.literal("İlerleme sıfırlandı."), false);
							return 1;
						}))));
	}

	// ---------------------------------------------------------------- portal
	public static void openPortal(ServerPlayerEntity p) {
		ServerWorld w = p.getServerWorld();
		if (isLiminal(w)) {
			p.sendMessage(Text.literal("Zaten buradasın. Çıkışı bulmak için kitabı bul.").formatted(Formatting.DARK_RED), true);
			return;
		}
		LiminalState st = LiminalState.get(p.getServer());
		LiminalState.Data d = st.get(p.getUuid());
		if (Integer.bitCount(d.collected) >= TOTAL) {
			p.sendMessage(Text.literal("Bütün kitaplar toplandı.").formatted(Formatting.DARK_RED), true);
			return;
		}
		BlockPos pos = p.getBlockPos();
		if (!(w.getBlockState(pos).isAir() || w.getBlockState(pos).isReplaceable())) {
			pos = pos.up();
		}
		w.setBlockState(pos, ModBlocks.PORTAL.getDefaultState());
		w.playSound(null, pos, SoundEvents.BLOCK_END_PORTAL_SPAWN, SoundCategory.AMBIENT, 1.0f, 0.5f);
		w.playSound(null, pos, SoundEvents.ENTITY_WARDEN_AMBIENT, SoundCategory.AMBIENT, 1.0f, 0.6f);
	}

	public static void onPortalTouched(ServerPlayerEntity p) {
		if (PENDING.containsKey(p.getUuid())) return;
		PENDING.put(p.getUuid(), 40);
		p.addStatusEffect(new StatusEffectInstance(StatusEffects.NAUSEA, 100, 0, false, false));
		p.addStatusEffect(new StatusEffectInstance(StatusEffects.DARKNESS, 100, 0, false, false));
		p.getServerWorld().playSound(null, p.getBlockPos(), SoundEvents.BLOCK_PORTAL_TRIGGER,
				SoundCategory.AMBIENT, 1.0f, 0.5f);
	}

	// ------------------------------------------------------------------ tick
	private static void tick(MinecraftServer server) {
		LiminalState st = LiminalState.get(server);

		Iterator<Map.Entry<UUID, Integer>> it = PENDING.entrySet().iterator();
		List<ServerPlayerEntity> toEnter = new ArrayList<>();
		while (it.hasNext()) {
			Map.Entry<UUID, Integer> e = it.next();
			ServerPlayerEntity p = server.getPlayerManager().getPlayer(e.getKey());
			if (p == null) {
				it.remove();
				continue;
			}
			int t = e.getValue() - 1;
			if (t <= 0) {
				it.remove();
				toEnter.add(p);
			} else {
				e.setValue(t);
			}
		}
		for (ServerPlayerEntity p : toEnter) {
			LiminalState.Data d = st.get(p.getUuid());
			List<Integer> avail = new ArrayList<>();
			for (int i = 0; i < TOTAL; i++) if (((d.collected >> i) & 1) == 0) avail.add(i);
			if (avail.isEmpty()) continue;
			enterLevel(p, st, avail.get(RNG.nextInt(avail.size())));
		}

		int now = server.getTicks();
		for (ServerPlayerEntity p : new ArrayList<>(server.getPlayerManager().getPlayerList())) {
			ServerWorld w = p.getServerWorld();
			LiminalState.Data d = st.players.get(p.getUuid());

			if (d != null) {
				// kitabı aldı mı?
				if (d.current >= 0 && d.returnTimer < 0
						&& w.getRegistryKey().equals(levelKey(d.current)) && hasBook(p, d.current)) {
					d.returnTimer = 100;
					st.markDirty();
					w.playSound(null, p.getBlockPos(), SoundEvents.BLOCK_END_PORTAL_SPAWN, SoundCategory.AMBIENT, 0.8f, 1.6f);
				}
				if (d.returnTimer > 0) {
					if (d.returnTimer % 20 == 0) {
						p.sendMessage(Text.literal("Geri dönüşe " + (d.returnTimer / 20) + "...").formatted(Formatting.WHITE), true);
					}
					d.returnTimer--;
					if (d.returnTimer == 0) complete(p, st, d);
				}
				if (d.finaleTimer > 0) {
					d.finaleTimer--;
					if (d.finaleTimer == 0) {
						d.finaleTimer = -1;
						enterFinale(p, st, d);
					}
				}
				// canavar sayısını koru
				if (d.current >= 0 && now % 100 == 0 && w.getRegistryKey().equals(levelKey(d.current))) {
					LevelBuilder.ensureMobs(w, d.current);
				}
			}

			if (w.getRegistryKey().equals(FINALE)) finaleEffects(p, w, now);
		}
	}

	private static boolean hasBook(ServerPlayerEntity p, int idx) {
		PlayerInventory inv = p.getInventory();
		for (int i = 0; i < inv.size(); i++) {
			ItemStack s = inv.getStack(i);
			if (s.isOf(Items.WRITTEN_BOOK) && s.hasNbt() && s.getNbt().getInt("liminalgod_level") == idx + 1) {
				return true;
			}
		}
		return false;
	}

	// ------------------------------------------------------ enter / leave
	public static void enterLevel(ServerPlayerEntity p, LiminalState st, int idx) {
		MinecraftServer server = p.getServer();
		ServerWorld lw = server.getWorld(levelKey(idx));
		if (lw == null) {
			p.sendMessage(Text.literal("Boyut bulunamadı: " + levelKey(idx).getValue()), false);
			return;
		}
		LiminalState.Data d = st.get(p.getUuid());
		ServerWorld cur = p.getServerWorld();
		if (!isLiminal(cur)) {
			d.hasRet = true;
			d.retWorld = cur.getRegistryKey().getValue().toString();
			d.x = p.getX();
			d.y = p.getY();
			d.z = p.getZ();
			d.yaw = p.getYaw();
			d.pitch = p.getPitch();
		}
		d.current = idx;
		d.returnTimer = -1;
		if (((st.built >> idx) & 1) == 0) {
			LevelBuilder.build(lw, idx);
			st.built |= 1 << idx;
		}
		p.removeStatusEffect(StatusEffects.NAUSEA);
		p.removeStatusEffect(StatusEffects.DARKNESS);
		p.teleport(lw, LevelBuilder.START_X, LevelBuilder.FLOOR + 1, LevelBuilder.START_Z, RNG.nextFloat() * 360f, 0f);
		p.sendMessage(Text.literal(Levels.DEFS[idx].name).formatted(Formatting.GRAY), true);
		st.markDirty();
	}

	private static void complete(ServerPlayerEntity p, LiminalState st, LiminalState.Data d) {
		d.collected |= 1 << d.current;
		exit(p, d);
		int n = Integer.bitCount(d.collected);
		p.sendMessage(Text.literal("Kitap " + n + "/" + TOTAL).formatted(Formatting.GRAY), true);
		if (n >= TOTAL && !d.finale) d.finaleTimer = 100;
		st.markDirty();
	}

	private static void exit(ServerPlayerEntity p, LiminalState.Data d) {
		MinecraftServer s = p.getServer();
		ServerWorld rw = s.getWorld(RegistryKey.of(RegistryKeys.WORLD, new Identifier(d.retWorld)));
		if (rw == null) rw = s.getOverworld();
		d.current = -1;
		d.returnTimer = -1;
		p.removeStatusEffect(StatusEffects.NAUSEA);
		p.removeStatusEffect(StatusEffects.DARKNESS);
		if (d.hasRet) {
			p.teleport(rw, d.x, d.y, d.z, d.yaw, d.pitch);
		} else {
			BlockPos sp = rw.getSpawnPos();
			p.teleport(rw, sp.getX() + 0.5, sp.getY(), sp.getZ() + 0.5, 0f, 0f);
		}
	}

	// ---------------------------------------------------------------- finale
	public static void enterFinale(ServerPlayerEntity p, LiminalState st, LiminalState.Data d) {
		MinecraftServer server = p.getServer();
		ServerWorld fw = server.getWorld(FINALE);
		if (fw == null) {
			p.sendMessage(Text.literal("Final boyutu bulunamadı."), false);
			return;
		}
		if (((st.built >> 15) & 1) == 0) {
			LevelBuilder.buildFinale(fw);
			st.built |= 1 << 15;
		}
		d.finale = true;
		d.current = -1;
		p.teleport(fw, 40.5, LevelBuilder.FLOOR + 1, 62.5, 180f, 0f);
		st.markDirty();
	}

	private static void finaleEffects(ServerPlayerEntity p, ServerWorld w, int now) {
		if (now % 20 == 0) {
			p.sendMessage(Text.literal("tanrı geliyor..").formatted(Formatting.RED), true); // küçük kırmızı yazı
		}
		if (now % 60 == 0) {
			w.playSound(null, p.getBlockPos(), SoundEvents.ENTITY_GHAST_SCREAM, SoundCategory.HOSTILE, 2.0f, 0.5f);
		}
		if (now % 100 == 30) {
			w.playSound(null, p.getBlockPos(), SoundEvents.ENTITY_WARDEN_ROAR, SoundCategory.HOSTILE, 1.5f, 0.6f);
		}
		if (now % 140 == 70) {
			w.playSound(null, p.getBlockPos(), SoundEvents.ENTITY_ENDERMAN_SCREAM, SoundCategory.HOSTILE, 2.0f, 0.4f);
		}
		if (now % 2 == 0) {
			// gökyüzünden inen beyaz ışık parçacıkları
			for (int y = 100; y > 66; y -= 6) {
				w.spawnParticles(ParticleTypes.END_ROD, 40.5 + (RNG.nextDouble() - 0.5) * 2, y + RNG.nextInt(6),
						40.5 + (RNG.nextDouble() - 0.5) * 2, 0, 0, -1, 0, 0.6);
			}
		}
	}
}
