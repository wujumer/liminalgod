package com.liminalgod;

import net.minecraft.block.Blocks;

public final class Levels {
	public static final LevelDef[] DEFS = {
		// 1
		new LevelDef("Sararmış Odalar")
			.floor(Blocks.BROWN_WOOL).wall(Blocks.SMOOTH_SANDSTONE).ceil(Blocks.WHITE_TERRACOTTA)
			.light(Blocks.SHROOMLIGHT, 2).mobs(2),
		// 2
		new LevelDef("Havuz Odaları").open()
			.floor(Blocks.SMOOTH_QUARTZ).floor2(Blocks.LIGHT_BLUE_CONCRETE)
			.wall(Blocks.WHITE_CONCRETE).ceil(Blocks.WHITE_CONCRETE)
			.light(Blocks.SEA_LANTERN, 1).pillars().water(1).bright().mobs(3),
		// 3
		new LevelDef("Çimenli Salon").open()
			.floor(Blocks.GRASS_BLOCK).path(Blocks.GRAY_CONCRETE)
			.wall(Blocks.LIGHT_GRAY_CONCRETE).ceil(Blocks.LIGHT_GRAY_CONCRETE)
			.light(Blocks.SEA_LANTERN, 1).pillars().bright()
			.props(0.8, Blocks.GRASS, Blocks.DANDELION, Blocks.ORANGE_TULIP, Blocks.DANDELION, Blocks.AZURE_BLUET)
			.mobs(3),
		// 4
		new LevelDef("Neşe Sirki")
			.floor(Blocks.RED_WOOL).floor2(Blocks.WHITE_WOOL)
			.wall(Blocks.PURPLE_CONCRETE).ceil(Blocks.YELLOW_CONCRETE)
			.light(Blocks.GLOWSTONE, 1).bright()
			.props(0.5, Blocks.CAKE, Blocks.NOTE_BLOCK, Blocks.PINK_WOOL, Blocks.LIGHT_BLUE_WOOL, Blocks.YELLOW_WOOL)
			.mobs(3),
		// 5
		new LevelDef("Okul Koridoru")
			.floor(Blocks.LIGHT_GRAY_TERRACOTTA).floor2(Blocks.WHITE_TERRACOTTA)
			.wall(Blocks.LIGHT_BLUE_TERRACOTTA).ceil(Blocks.WHITE_CONCRETE)
			.light(Blocks.SEA_LANTERN, 2)
			.props(0.5, Blocks.BOOKSHELF, Blocks.LECTERN, Blocks.CRAFTING_TABLE)
			.mobs(3),
		// 6
		new LevelDef("Otopark").open()
			.floor(Blocks.GRAY_CONCRETE).wall(Blocks.LIGHT_GRAY_CONCRETE).ceil(Blocks.SMOOTH_STONE)
			.light(Blocks.LANTERN, 3).pillars()
			.props(0.4, Blocks.IRON_BARS, Blocks.BLACK_CONCRETE, Blocks.GRAY_CONCRETE)
			.mobs(4),
		// 7
		new LevelDef("Alışveriş Merkezi").open()
			.floor(Blocks.SMOOTH_QUARTZ).floor2(Blocks.LIGHT_GRAY_CONCRETE)
			.wall(Blocks.QUARTZ_BLOCK).ceil(Blocks.WHITE_CONCRETE)
			.light(Blocks.SEA_LANTERN, 1).pillars().bright()
			.props(0.4, Blocks.WHITE_WOOL, Blocks.OAK_FENCE, Blocks.WHITE_STAINED_GLASS)
			.mobs(4),
		// 8
		new LevelDef("Hastane")
			.floor(Blocks.LIGHT_GRAY_CONCRETE).wall(Blocks.WHITE_CONCRETE).ceil(Blocks.WHITE_CONCRETE)
			.light(Blocks.SEA_LANTERN, 3)
			.props(0.4, Blocks.WHITE_BED, Blocks.IRON_BARS, Blocks.CAULDRON)
			.mobs(4),
		// 9
		new LevelDef("Otel")
			.floor(Blocks.RED_WOOL).wall(Blocks.DARK_OAK_PLANKS).ceil(Blocks.SPRUCE_PLANKS)
			.light(Blocks.LANTERN, 2)
			.props(0.4, Blocks.BOOKSHELF, Blocks.DARK_OAK_FENCE, Blocks.BARREL)
			.mobs(3),
		// 10
		new LevelDef("Ofis")
			.floor(Blocks.GRAY_WOOL).wall(Blocks.LIGHT_GRAY_CONCRETE).ceil(Blocks.WHITE_CONCRETE)
			.light(Blocks.SEA_LANTERN, 2).bright()
			.props(0.4, Blocks.CRAFTING_TABLE, Blocks.BOOKSHELF, Blocks.COMPOSTER, Blocks.BLACK_CONCRETE)
			.mobs(3),
		// 11
		new LevelDef("Oyun Odası")
			.floor(Blocks.YELLOW_WOOL).floor2(Blocks.LIGHT_BLUE_WOOL)
			.wall(Blocks.PINK_WOOL).ceil(Blocks.WHITE_WOOL)
			.light(Blocks.GLOWSTONE, 2).bright()
			.props(0.6, Blocks.RED_WOOL, Blocks.BLUE_WOOL, Blocks.YELLOW_WOOL, Blocks.GREEN_WOOL, Blocks.PINK_BED)
			.mobs(3),
		// 12
		new LevelDef("Metro İstasyonu").open()
			.floor(Blocks.LIGHT_GRAY_CONCRETE).wall(Blocks.WHITE_TERRACOTTA).ceil(Blocks.GRAY_CONCRETE)
			.light(Blocks.SEA_LANTERN, 2).pillars()
			.props(0.3, Blocks.OAK_STAIRS, Blocks.IRON_BARS)
			.mobs(4),
		// 13
		new LevelDef("Sular Altındaki Apartman")
			.floor(Blocks.GRAY_TERRACOTTA).wall(Blocks.LIGHT_GRAY_TERRACOTTA).ceil(Blocks.LIGHT_GRAY_CONCRETE)
			.light(Blocks.SEA_LANTERN, 3).water(3).mobs(4),
		// 14
		new LevelDef("Terk Edilmiş Kilise").open()
			.floor(Blocks.DEEPSLATE_TILES).path(Blocks.RED_WOOL)
			.wall(Blocks.DEEPSLATE_BRICKS).ceil(Blocks.DEEPSLATE_BRICKS)
			.light(Blocks.SOUL_LANTERN, 2).pillars()
			.props(0.35, Blocks.CANDLE, Blocks.COBWEB, Blocks.BONE_BLOCK)
			.mobs(5),
		// 15
		new LevelDef("Et Koridoru")
			.floor(Blocks.PINK_TERRACOTTA).wall(Blocks.NETHER_WART_BLOCK).ceil(Blocks.NETHER_WART_BLOCK)
			.light(Blocks.SHROOMLIGHT, 3)
			.props(0.4, Blocks.BONE_BLOCK, Blocks.RED_MUSHROOM_BLOCK)
			.mobs(6),
	};

	private Levels() {}
}
