package com.liminalgod.client;

import com.liminalgod.AnomalyEntity;
import com.liminalgod.LiminalGod;
import net.minecraft.client.render.OverlayTexture;
import net.minecraft.client.render.RenderLayer;
import net.minecraft.client.render.VertexConsumer;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.render.entity.EntityRendererFactory;
import net.minecraft.client.render.entity.MobEntityRenderer;
import net.minecraft.client.render.entity.feature.FeatureRenderer;
import net.minecraft.client.render.entity.feature.FeatureRendererContext;
import net.minecraft.client.render.entity.model.EntityModelLayers;
import net.minecraft.client.render.entity.model.ZombieEntityModel;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.util.Identifier;

public class AnomalyRenderer extends MobEntityRenderer<AnomalyEntity, ZombieEntityModel<AnomalyEntity>> {
	public static final Identifier[] TEX = new Identifier[15];
	public static final Identifier[] EYES = new Identifier[15];

	static {
		for (int i = 0; i < 15; i++) {
			TEX[i] = new Identifier(LiminalGod.MOD_ID, "textures/entity/anomaly_" + i + ".png");
			EYES[i] = new Identifier(LiminalGod.MOD_ID, "textures/entity/anomaly_" + i + "_eyes.png");
		}
	}

	public AnomalyRenderer(EntityRendererFactory.Context ctx) {
		super(ctx, new ZombieEntityModel<>(ctx.getPart(EntityModelLayers.ZOMBIE)), 0.5f);
		this.addFeature(new EyesLayer(this));
	}

	@Override
	public Identifier getTexture(AnomalyEntity entity) {
		return TEX[Math.floorMod(entity.getVariant(), 15)];
	}

	@Override
	protected void scale(AnomalyEntity entity, MatrixStack matrices, float amount) {
		matrices.scale(0.95f, 1.3f, 0.95f); // uzun ve ince siluet
	}

	/** Karanlıkta parlayan gözler. */
	static class EyesLayer extends FeatureRenderer<AnomalyEntity, ZombieEntityModel<AnomalyEntity>> {
		EyesLayer(FeatureRendererContext<AnomalyEntity, ZombieEntityModel<AnomalyEntity>> ctx) {
			super(ctx);
		}

		@Override
		public void render(MatrixStack matrices, VertexConsumerProvider vcp, int light, AnomalyEntity e,
						   float limbAngle, float limbDistance, float tickDelta, float animationProgress,
						   float headYaw, float headPitch) {
			VertexConsumer vc = vcp.getBuffer(RenderLayer.getEyes(EYES[Math.floorMod(e.getVariant(), 15)]));
			this.getContextModel().render(matrices, vc, 15728640, OverlayTexture.DEFAULT_UV, 1f, 1f, 1f, 1f);
		}
	}
}
