package com.liminalgod;

import net.minecraft.block.*;
import net.minecraft.block.entity.BlockEntity;
import net.minecraft.block.entity.ChestBlockEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Direction;

import java.util.*;

/** Mekanları kodla, sıfırdan inşa eder (NBT yapı dosyası gerekmez). */
public final class LevelBuilder {
	public static final int FLOOR = 64, H = 5, CELL = 8, N = 10, S = N * CELL;
	public static final double START_X = 4.5, START_Z = 4.5;
	private static final int FLAGS = Block.NOTIFY_LISTENERS | Block.FORCE_STATE;

	private static void set(ServerWorld w, int x, int y, int z, BlockState s) {
		w.setBlockState(new BlockPos(x, y, z), s, FLAGS);
	}

	private static boolean lane(int l) {
		return l >= 3 && l <= 5;
	}

	// ------------------------------------------------------------ seviye inşası
	public static void build(ServerWorld w, int idx) {
		LevelDef d = Levels.DEFS[idx];
		Random r = new Random(7000L + idx * 131L);
		BlockState wall = d.wall.getDefaultState();
		BlockState water = Blocks.WATER.getDefaultState();

		boolean[][] oe = new boolean[N][N]; // (x,z) ile (x+1,z) arası geçit
		boolean[][] os = new boolean[N][N]; // (x,z) ile (x,z+1) arası geçit
		if (!d.open) carve(r, oe, os);

		// zemin, tavan, su
		for (int x = 0; x <= S; x++) {
			for (int z = 0; z <= S; z++) {
				int lx = x % CELL, lz = z % CELL;
				BlockState fl = d.floor.getDefaultState();
				if (d.floor2 != null && (((x / 2) + (z / 2)) & 1) == 0) fl = d.floor2.getDefaultState();
				if (d.open && d.path != null && x < S && z < S && (lane(lx) || lane(lz))) fl = d.path.getDefaultState();
				set(w, x, FLOOR, z, fl);
				set(w, x, FLOOR + H + 1, z, d.ceil.getDefaultState());
				for (int y = 1; y <= d.water; y++) set(w, x, FLOOR + y, z, water);
			}
		}

		// dış duvarlar
		for (int i = 0; i <= S; i++) {
			for (int y = 1; y <= H; y++) {
				set(w, 0, FLOOR + y, i, wall);
				set(w, S, FLOOR + y, i, wall);
				set(w, i, FLOOR + y, 0, wall);
				set(w, i, FLOOR + y, S, wall);
			}
		}

		// iç duvarlar (labirent) veya kolonlar (açık salon)
		for (int cx = 0; cx < N; cx++) {
			for (int cz = 0; cz < N; cz++) {
				int x0 = cx * CELL, z0 = cz * CELL;
				if (!d.open) {
					for (int i = 0; i <= CELL; i++) {
						boolean doorW = cx > 0 && oe[cx - 1][cz] && i >= 3 && i <= 5;
						boolean doorN = cz > 0 && os[cx][cz - 1] && i >= 3 && i <= 5;
						for (int y = 1; y <= H; y++) {
							if (!(doorW && y <= 4)) set(w, x0, FLOOR + y, z0 + i, wall);
							if (!(doorN && y <= 4)) set(w, x0 + i, FLOOR + y, z0, wall);
						}
					}
				} else if (d.pillars && cx >= 1 && cz >= 1) {
					for (int dx = 0; dx < 2; dx++)
						for (int dz = 0; dz < 2; dz++)
							for (int y = 1; y <= H; y++) set(w, x0 + dx, FLOOR + y, z0 + dz, wall);
				}
			}
		}

		// ışıklar
		Block lb = d.light;
		boolean lantern = lb == Blocks.LANTERN || lb == Blocks.SOUL_LANTERN;
		for (int cx = 0; cx < N; cx++) {
			for (int cz = 0; cz < N; cz++) {
				if ((cx + cz) % d.lightEvery != 0) continue;
				int x0 = cx * CELL, z0 = cz * CELL;
				int[][] spots = d.bright
						? new int[][]{{2, 2}, {6, 2}, {2, 6}, {6, 6}}
						: new int[][]{{4, 4}};
				for (int[] sp : spots) {
					if (lantern) {
						set(w, x0 + sp[0], FLOOR + H, z0 + sp[1], lb.getDefaultState().with(LanternBlock.HANGING, true));
					} else {
						set(w, x0 + sp[0], FLOOR + H + 1, z0 + sp[1], lb.getDefaultState());
					}
				}
			}
		}

		// eşyalar / bitkiler (koridorlara dokunmadan, köşelere)
		if (d.props.length > 0 && d.water == 0) {
			for (int cx = 0; cx < N; cx++) {
				for (int cz = 0; cz < N; cz++) {
					for (int lx = 1; lx <= 7; lx++) {
						for (int lz = 1; lz <= 7; lz++) {
							if (lane(lx) || lane(lz)) continue;
							if (r.nextDouble() < d.propChance) {
								set(w, cx * CELL + lx, FLOOR + 1, cz * CELL + lz,
										d.props[r.nextInt(d.props.length)].getDefaultState());
							}
						}
					}
				}
			}
		}

		// sandığın yeri: başlangıçtan en uzak hücre
		int[] best = d.open ? new int[]{N - 1, N - 1} : farthestCell(oe, os);
		placeChest(w, d, idx, best[0] * CELL + 4, best[1] * CELL + 4);

		ensureMobs(w, idx);
	}

	private static void placeChest(ServerWorld w, LevelDef d, int idx, int cx, int cz) {
		int ph = Math.max(1, d.water);
		BlockState podium = d.floor.getDefaultState();
		for (int dx = -1; dx <= 1; dx++) {
			for (int dz = -1; dz <= 1; dz++) {
				for (int y = 1; y <= ph; y++) set(w, cx + dx, FLOOR + y, cz + dz, podium);
				// çevredeki eşyaları temizle
				for (int y = ph + 1; y <= H - 1; y++) set(w, cx + dx, FLOOR + y, cz + dz, Blocks.AIR.getDefaultState());
			}
		}
		int cy = FLOOR + ph + 1;
		set(w, cx, cy, cz, Blocks.CHEST.getDefaultState().with(ChestBlock.FACING, Direction.NORTH));
		BlockEntity be = w.getBlockEntity(new BlockPos(cx, cy, cz));
		if (be instanceof ChestBlockEntity chest) {
			chest.setStack(13, Stories.book(idx));
		}
		BlockState candle = Blocks.CANDLE.getDefaultState().with(CandleBlock.LIT, true);
		set(w, cx - 1, cy, cz - 1, candle);
		set(w, cx + 1, cy, cz - 1, candle);
		set(w, cx - 1, cy, cz + 1, candle);
		set(w, cx + 1, cy, cz + 1, candle);
	}

	// ----------------------------------------------------------------- labirent
	private static void carve(Random r, boolean[][] oe, boolean[][] os) {
		int[] dx = {1, -1, 0, 0}, dz = {0, 0, 1, -1};
		boolean[][] vis = new boolean[N][N];
		Deque<int[]> stack = new ArrayDeque<>();
		vis[0][0] = true;
		stack.push(new int[]{0, 0});
		while (!stack.isEmpty()) {
			int[] c = stack.peek();
			List<Integer> dirs = new ArrayList<>();
			for (int k = 0; k < 4; k++) {
				int nx = c[0] + dx[k], nz = c[1] + dz[k];
				if (nx >= 0 && nz >= 0 && nx < N && nz < N && !vis[nx][nz]) dirs.add(k);
			}
			if (dirs.isEmpty()) {
				stack.pop();
				continue;
			}
			int k = dirs.get(r.nextInt(dirs.size()));
			int nx = c[0] + dx[k], nz = c[1] + dz[k];
			switch (k) {
				case 0 -> oe[c[0]][c[1]] = true;
				case 1 -> oe[nx][nz] = true;
				case 2 -> os[c[0]][c[1]] = true;
				default -> os[nx][nz] = true;
			}
			vis[nx][nz] = true;
			stack.push(new int[]{nx, nz});
		}
		// döngüler için fazladan geçitler
		for (int x = 0; x < N; x++) {
			for (int z = 0; z < N; z++) {
				if (x < N - 1 && r.nextDouble() < 0.12) oe[x][z] = true;
				if (z < N - 1 && r.nextDouble() < 0.12) os[x][z] = true;
			}
		}
	}

	private static int[] farthestCell(boolean[][] oe, boolean[][] os) {
		int[][] dist = new int[N][N];
		for (int[] row : dist) Arrays.fill(row, -1);
		Deque<int[]> q = new ArrayDeque<>();
		dist[0][0] = 0;
		q.add(new int[]{0, 0});
		int[] best = {0, 0};
		while (!q.isEmpty()) {
			int[] c = q.poll();
			int x = c[0], z = c[1];
			if (dist[x][z] > dist[best[0]][best[1]]) best = c;
			if (oe[x][z] && dist[x + 1][z] < 0) { dist[x + 1][z] = dist[x][z] + 1; q.add(new int[]{x + 1, z}); }
			if (x > 0 && oe[x - 1][z] && dist[x - 1][z] < 0) { dist[x - 1][z] = dist[x][z] + 1; q.add(new int[]{x - 1, z}); }
			if (os[x][z] && dist[x][z + 1] < 0) { dist[x][z + 1] = dist[x][z] + 1; q.add(new int[]{x, z + 1}); }
			if (z > 0 && os[x][z - 1] && dist[x][z - 1] < 0) { dist[x][z - 1] = dist[x][z] + 1; q.add(new int[]{x, z - 1}); }
		}
		return best;
	}

	// ----------------------------------------------------------------- canavarlar
	public static void ensureMobs(ServerWorld w, int idx) {
		LevelDef d = Levels.DEFS[idx];
		List<AnomalyEntity> existing = w.getEntitiesByType(ModEntities.ANOMALY,
				new Box(0, FLOOR - 2, 0, S + 1, FLOOR + 20, S + 1), e -> true);
		int need = d.mobs - existing.size();
		Random r = new Random();
		for (int i = 0; i < need; i++) {
			int cx, cz;
			do {
				cx = r.nextInt(N);
				cz = r.nextInt(N);
			} while (cx + cz < 4);
			AnomalyEntity m = ModEntities.ANOMALY.create(w);
			if (m == null) continue;
			m.refreshPositionAndAngles(cx * CELL + 4 + r.nextInt(3) - 1, FLOOR + 1, cz * CELL + 4 + r.nextInt(3) - 1,
					r.nextFloat() * 360f, 0f);
			m.setVariant(idx);
			m.setPersistent();
			w.spawnEntity(m);
		}
	}

	// ------------------------------------------------------------------- final
	public static void buildFinale(ServerWorld w) {
		BlockState white = Blocks.WHITE_CONCRETE.getDefaultState();
		int top = FLOOR + 40;
		int size = 80;
		for (int x = 0; x <= size; x++) {
			for (int z = 0; z <= size; z++) {
				set(w, x, FLOOR, z, white);
				boolean hole = Math.abs(x - 40) <= 1 && Math.abs(z - 40) <= 1;
				if (!hole) set(w, x, top, z, white);
				if (x == 0 || z == 0 || x == size || z == size) {
					for (int y = FLOOR + 1; y < top; y++) set(w, x, y, z, white);
				}
			}
		}
		BlockState light = Blocks.LIGHT.getDefaultState();
		for (int x = 5; x < size; x += 10)
			for (int z = 5; z < size; z += 10)
				for (int y = FLOOR + 2; y < top; y += 12) set(w, x, y, z, light);
		set(w, 40, FLOOR + 1, 40, Blocks.BEACON.getDefaultState()); // bembeyaz ışık sütunu
	}
}
