package com.liminalgod;

import net.minecraft.block.Block;

/** Bir liminal mekanın tarifi. */
public class LevelDef {
	public final String name;
	public boolean open;          // true: büyük açık salon, false: labirent odalar
	public Block floor, floor2, path, wall, ceil, light;
	public int lightEvery = 2;
	public Block[] props = {};
	public double propChance = 0;
	public boolean pillars;
	public int water;             // su derinliği
	public boolean bright;
	public int mobs = 3;

	public LevelDef(String name) { this.name = name; }

	public LevelDef open() { this.open = true; return this; }
	public LevelDef floor(Block b) { this.floor = b; return this; }
	public LevelDef floor2(Block b) { this.floor2 = b; return this; }
	public LevelDef path(Block b) { this.path = b; return this; }
	public LevelDef wall(Block b) { this.wall = b; return this; }
	public LevelDef ceil(Block b) { this.ceil = b; return this; }
	public LevelDef light(Block b, int every) { this.light = b; this.lightEvery = every; return this; }
	public LevelDef props(double chance, Block... b) { this.props = b; this.propChance = chance; return this; }
	public LevelDef pillars() { this.pillars = true; return this; }
	public LevelDef water(int depth) { this.water = depth; return this; }
	public LevelDef bright() { this.bright = true; return this; }
	public LevelDef mobs(int n) { this.mobs = n; return this; }
}
