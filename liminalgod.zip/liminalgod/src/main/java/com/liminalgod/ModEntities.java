package com.liminalgod;

import net.fabricmc.fabric.api.object.builder.v1.entity.FabricDefaultAttributeRegistry;
import net.fabricmc.fabric.api.object.builder.v1.entity.FabricEntityTypeBuilder;
import net.minecraft.entity.EntityDimensions;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.SpawnGroup;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;

public class ModEntities {
	public static final EntityType<AnomalyEntity> ANOMALY = Registry.register(Registries.ENTITY_TYPE,
			LiminalGod.id("anomaly"),
			FabricEntityTypeBuilder.<AnomalyEntity>create(SpawnGroup.MONSTER, AnomalyEntity::new)
					.dimensions(EntityDimensions.fixed(0.6f, 2.5f))
					.trackRangeBlocks(96)
					.build());

	public static void init() {
		FabricDefaultAttributeRegistry.register(ANOMALY, AnomalyEntity.createAttributes());
	}
}
