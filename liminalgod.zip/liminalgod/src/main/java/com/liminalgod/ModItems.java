package com.liminalgod;

import net.fabricmc.fabric.api.item.v1.FabricItemSettings;
import net.fabricmc.fabric.api.itemgroup.v1.ItemGroupEvents;
import net.minecraft.item.Item;
import net.minecraft.item.ItemGroups;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;

public class ModItems {
	public static final Item PORTAL_KEY = Registry.register(Registries.ITEM, LiminalGod.id("portal_key"),
			new PortalItem(new FabricItemSettings().maxCount(1)));

	public static void init() {
		ItemGroupEvents.modifyEntriesEvent(ItemGroups.TOOLS).register(e -> e.add(PORTAL_KEY));
	}
}
