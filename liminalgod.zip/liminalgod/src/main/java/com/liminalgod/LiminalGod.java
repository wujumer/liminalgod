package com.liminalgod;

import net.fabricmc.api.ModInitializer;
import net.minecraft.util.Identifier;

public class LiminalGod implements ModInitializer {
	public static final String MOD_ID = "liminalgod";

	public static Identifier id(String path) {
		return new Identifier(MOD_ID, path);
	}

	@Override
	public void onInitialize() {
		ModBlocks.init();
		ModItems.init();
		ModEntities.init();
		LiminalManager.init();
	}
}
