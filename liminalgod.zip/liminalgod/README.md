# Liminal: Tanrının Oyuncakları (Fabric 1.20.1)

15 liminal mekan, 15 kitap, 15 canavar ve bembeyaz bir final.

## Oynanış
1. **Eşik Anahtarı** yap: 1 Ender İncisi + 1 Kitap + 1 Mürekkep Kesesi (şekilsiz tarif). Ya da OP: `/liminal key`
2. Anahtara sağ tıkla → ayağının altında portal açılır (ses çıkar), içine basınca ekran bulanır, 2 saniye sonra rastgele bir mekâna ışınlanırsın.
3. Mekânda labirent/salon içindeki **sandığı** bul (etrafında yanan mumlar var, başlangıçtan en uzak noktada). İçindeki kitabı al → 5 saniye sonra eski yerine dönersin.
4. 15 kitabı topla → 5 sn sonra bembeyaz salona ışınlanırsın: yukarıdan beyaz ışık, çığlıklar, ekranda küçük kırmızı "tanrı geliyor.."

## Komutlar (OP)
- `/liminal key` anahtarı ver
- `/liminal go <1-15>` doğrudan o mekâna git (test için)
- `/liminal finale` finali test et
- `/liminal leave` dışarı çık
- `/liminal reset` kendi ilerlemeni sıfırla

## Önemli
- Oyun zorluğu **Kolay veya üstü** olmalı (Barışçıl'da canavarlar silinir).
- Dünyayı oluşturan herkes modu kurmalı (Fabric Loader + Fabric API gerekli).
- Mekânlarda blok kırılamaz (yaratıcı modda kırılır).

## Derleme (jar üretme)
**En kolayı:** bu klasörü GitHub'a yükle → "Actions" sekmesinde `build` çalışır → çıkan `liminalgod-jar` dosyasını indir.
Ya da bilgisayarında JDK 17 ve Gradle 8.5+ varsa: `gradle build` → `build/libs/liminalgod-1.0.0.jar`
(`tools/gen_assets.py` canavar dokularını ve JSON'ları yeniden üretir.)
