package com.liminalgod.client;

import com.liminalgod.AnomalyEntity;
import com.liminalgod.LiminalGod;
import net.minecraft.client.model.ModelPart;
import net.minecraft.client.render.OverlayTexture;
import net.minecraft.client.render.RenderLayer;
import net.minecraft.client.render.VertexConsumer;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.render.entity.EntityRendererFactory;
import net.minecraft.client.render.entity.MobEntityRenderer;
import net.minecraft.client.render.entity.feature.FeatureRenderer;
import net.minecraft.client.render.entity.feature.FeatureRendererContext;
import net.minecraft.client.render.entity.model.BipedEntityModel;
import net.minecraft.client.render.entity.model.CrossbowPosing;
import net.minecraft.client.render.entity.model.EntityModelLayers;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.util.Identifier;

public class AnomalyRenderer extends MobEntityRenderer<AnomalyEntity, AnomalyRenderer.AnomalyModel> {
	public static final Identifier[] TEX = new Identifier[15];
	public static final Identifier[] EYES = new Identifier[15];

	static {
		for (int i = 0; i < 15; i++) {
			TEX[i] = new Identifier(LiminalGod.MOD_ID, "textures/entity/anomaly_" + i + ".png");
			EYES[i] = new Identifier(LiminalGod.MOD_ID, "textures/entity/anomaly_" + i + "_eyes.png");
		}
	}

	public AnomalyRenderer(EntityRendererFactory.Context ctx) {
		super(ctx, new AnomalyModel(ctx.getPart(EntityModelLayers.ZOMBIE)), 0.5f);
		this.addFeature(new EyesLayer(this));
	}

	@Override
	public Identifier getTexture(AnomalyEntity entity) {
		return TEX[Math.floorMod(entity.getVariant(), 15)];
	}

	@Override
	protected void scale(AnomalyEntity entity, MatrixStack matrices, float amount) {
		matrices.scale(0.95f, 1.3f, 0.95f); // uzun ve ince siluet
	}

	/** Zombi iskeleti, kovalarken kollar öne uzanır. */
	public static class AnomalyModel extends BipedEntityModel<AnomalyEntity> {
		public AnomalyModel(ModelPart root) {
			super(root);
		}

		@Override
		public void setAngles(AnomalyEntity entity, float limbAngle, float limbDistance, float animationProgress,
							  float headYaw, float headPitch) {
			super.setAngles(entity, limbAngle, limbDistance, animationProgress, headYaw, headPitch);
			CrossbowPosing.meleeAttack(this.leftArm, this.rightArm, entity.isAttacking(),
					this.handSwingProgress, animationProgress);
		}
	}

	/** Karanlıkta parlayan gözler. */
	static class EyesLayer extends FeatureRenderer<AnomalyEntity, AnomalyModel> {
		EyesLayer(FeatureRendererContext<AnomalyEntity, AnomalyModel> ctx) {
			super(ctx);
		}

		@Override
		public void render(MatrixStack matrices, VertexConsumerProvider vcp, int light, AnomalyEntity e,
						   float limbAngle, float limbDistance, float tickDelta, float animationProgress,
						   float headYaw, float headPitch) {
			VertexConsumer vc = vcp.getBuffer(RenderLayer.getEyes(EYES[Math.floorMod(e.getVariant(), 15)]));
			this.getContextModel().render(matrices, vc, 15728640, OverlayTexture.DEFAULT_UV, 1f, 1f, 1f, 1f);
		}
	}
}
